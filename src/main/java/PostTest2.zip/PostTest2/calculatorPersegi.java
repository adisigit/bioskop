/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PostTest2;

/**
 *
 * @author DAVA RAJIF C
 */
 interface calculatorPersegi {
    
     public void hitungKeliling();
     public void hitungLuas();
}
